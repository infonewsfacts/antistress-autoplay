package com.antistress.autoplay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val reqCapture = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        fun text(s: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
            this.text = s
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, (6 * d).toInt(), 0, (6 * d).toInt())
        }

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        root.addView(text("AntiStress AutoPlay  v6", 24f, true))
        root.addView(text("Table Tennis प्रो-प्लेयर: सब कुछ अपने-आप, कोई सेटिंग नहीं।"))
        status = text("")
        root.addView(status)

        root.addView(text("स्टेप 1", 13f, true))
        root.addView(button("ओवरले अनुमति दें") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(text("स्टेप 2", 13f, true))
        root.addView(button("Accessibility सेवा चालू करें") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "'AntiStress AutoPlay' चुनकर चालू करें", Toast.LENGTH_LONG).show()
        })
        root.addView(text("स्टेप 3", 13f, true))
        root.addView(button("फ्लोटिंग बटन शुरू करें") { startBot() })

        root.addView(text(""))
        root.addView(button("बटन दिखाएँ / छुपाएँ") {
            if (BotService.alive) {
                startService(Intent(this, BotService::class.java).setAction(BotService.ACT_HIDE))
            } else {
                Toast.makeText(this, "पहले स्टेप 3 करें", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(button("पूरा बंद करें") {
            stopService(Intent(this, BotService::class.java))
        })

        root.addView(
            text(
                "\nगेम में Table Tennis खोलकर गोल बटन दबाएँ (ON)। बाकी सब बॉट खुद करता है: " +
                    "पहली बार बल्ले की चाल और देरी नापता है, फिर खेलते-खेलते अपने-आप सुधरता रहता है। " +
                    "रोकने के लिए बटन फिर दबाएँ। बटन देर तक दबाने पर छुपता है; वापस लाने के लिए " +
                    "स्टेटस बार नीचे खींचकर नोटिफिकेशन में 'बटन दिखाएँ' दबाएँ।",
                14f
            )
        )

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val ac = BotAccessibilityService.instance != null
        status.text = "ओवरले अनुमति: ${if (ov) "✅" else "❌"}    Accessibility: ${if (ac) "✅" else "❌"}"
    }

    private fun startBot() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "पहले स्टेप 1 करें", Toast.LENGTH_LONG).show()
            return
        }
        if (BotAccessibilityService.instance == null) {
            Toast.makeText(this, "पहले स्टेप 2 करें", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, BotService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(i)
                Toast.makeText(this, "बटन तैयार है — अब गेम खोलें", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "स्क्रीन कैप्चर की अनुमति नहीं मिली", Toast.LENGTH_LONG).show()
            }
        }
    }
}
