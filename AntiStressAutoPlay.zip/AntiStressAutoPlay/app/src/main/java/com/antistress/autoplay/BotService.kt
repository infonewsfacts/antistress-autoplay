package com.antistress.autoplay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.app.PendingIntent
import android.graphics.Color
import android.graphics.drawable.Icon
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * फ्लोटिंग बटन + स्क्रीन कैप्चर + Engine चलाने वाली सर्विस।
 */
class BotService : Service() {

    companion object {
        @Volatile
        var alive = false
        const val ACT_HIDE = "com.antistress.autoplay.HIDE_SHOW"
        const val ACT_RUN = "com.antistress.autoplay.RUN_STOP"
        const val ACT_EXIT = "com.antistress.autoplay.EXIT"
    }

    private lateinit var wm: WindowManager
    private var lp: WindowManager.LayoutParams? = null
    private var attached = false
    private var hidden = false
    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var button: TextView? = null
    private var engine: Engine? = null

    @Volatile
    private var running = false
    private var destroyed = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent.action) {
            ACT_HIDE -> { if (projection != null) toggleHide() else stopSelf(); return START_NOT_STICKY }
            ACT_RUN -> { if (projection != null) toggle() else stopSelf(); return START_NOT_STICKY }
            ACT_EXIT -> { stopSelf(); return START_NOT_STICKY }
        }
        alive = true
        startForegroundCompat()
        if (projection == null) {
            val code = intent.getIntExtra("code", 0)
            @Suppress("DEPRECATION")
            val data: Intent? = intent.getParcelableExtra("data")
            if (data == null || !setupCapture(code, data)) {
                Toast.makeText(this, "स्क्रीन कैप्चर शुरू नहीं हुआ", Toast.LENGTH_LONG).show()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        if (button == null) addButton()
        return START_NOT_STICKY
    }

    private fun actionPi(action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code, Intent(this, BotService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun buildNotification(): Notification {
        val ch = "autoplay"
        val state = (if (running) "बॉट: चालू" else "बॉट: बंद") +
            " · " + (if (hidden) "बटन: छुपा" else "बटन: दिख रहा") +
            " · हिट ${engine?.hits ?: 0} · चूक ${engine?.misses ?: 0} · स्मैश ${engine?.smashes ?: 0}"
        fun act(label: String, action: String, code: Int) = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_view), label, actionPi(action, code)
        ).build()
        return Notification.Builder(this, ch)
            .setContentTitle("AntiStress AutoPlay")
            .setContentText(state)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOnlyAlertOnce(true)
            .addAction(act(if (hidden) "बटन दिखाएँ" else "बटन छुपाएँ", ACT_HIDE, 1))
            .addAction(act(if (running) "रोकें" else "शुरू करें", ACT_RUN, 2))
            .addAction(act("बंद करें", ACT_EXIT, 3))
            .build()
    }

    private fun updateNotif() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, buildNotification())
    }

    private fun startForegroundCompat() {
        val ch = "autoplay"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(ch, "AutoPlay", NotificationManager.IMPORTANCE_LOW)
        )
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun setupCapture(code: Int, data: Intent): Boolean {
        return try {
            val (sw, sh) = screenSize()
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data)
            projection = mp

            val t = HandlerThread("autoplay-capture").also { it.start() }
            thread = t
            val handler = Handler(t.looper)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopSelf() }
                }
            }, handler)

            val cw = 360
            val ch = (sh.toFloat() * cw / sw).roundToInt()
            val dpi = resources.displayMetrics.densityDpi
            val eng = Engine(sw, sh, getSharedPreferences("cfg", MODE_PRIVATE))
            engine = eng

            val r = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
            reader = r
            r.setOnImageAvailableListener({ rd ->
                var img: android.media.Image? = null
                try {
                    img = rd.acquireLatestImage()
                } catch (e: Exception) {
                    img = null
                }
                if (img == null) return@setOnImageAvailableListener
                try {
                    val p = img.planes[0]
                    eng.process(p.buffer, p.rowStride, img.width, img.height, running)
                } catch (e: Exception) {
                    // एक फ्रेम खराब हो तो अगला देखेंगे
                } finally {
                    img.close()
                }
            }, handler)

            display = mp.createVirtualDisplay(
                "autoplay", cw, ch, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, handler
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun addButton() {
        val (sw, sh) = screenSize()
        val size = dp(58)
        val tv = TextView(this).apply {
            text = "OFF"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.GRAY)
                setStroke(dp(2), Color.WHITE)
            }
            alpha = 0.9f
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (sw - size) / 2
            y = (0.065f * sh).toInt()   // ऊपर बीच में, गेम के खेलने वाले हिस्से से दूर
        }

        this.lp = lp
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var longPress: Runnable? = null
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                    longPress = Runnable {
                        if (!moved) {
                            hideButton(true)
                        }
                    }
                    main.postDelayed(longPress!!, 1200)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > slop || abs(e.rawY - downY) > slop) {
                        moved = true
                        main.removeCallbacks(longPress!!)
                        lp.x = startX + (e.rawX - downX).toInt()
                        lp.y = startY + (e.rawY - downY).toInt()
                        try { wm.updateViewLayout(tv, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    longPress?.let { main.removeCallbacks(it) }
                    if (!moved && e.action == MotionEvent.ACTION_UP) toggle()
                    true
                }
                else -> false
            }
        }
        button = tv
        wm.addView(tv, lp)
        attached = true
        refreshButton()
        main.post(tick)
    }

    private fun toggle() {
        if (!running) {
            if (BotAccessibilityService.instance == null) {
                Toast.makeText(this, "पहले Accessibility सेवा चालू करें", Toast.LENGTH_LONG).show()
                return
            }
            engine?.reset()
            running = true
        } else {
            running = false
            BotAccessibilityService.instance?.end()
            engine?.reset()
        }
        refreshButton()
        updateNotif()
    }

    private fun toggleHide() {
        if (hidden) showButton() else hideButton(false)
    }

    private fun hideButton(fromLongPress: Boolean) {
        val tv = button ?: return
        if (attached) {
            try { wm.removeView(tv) } catch (_: Exception) {}
            attached = false
        }
        hidden = true
        updateNotif()
        Toast.makeText(
            this,
            "बटन छुप गया। वापस लाने के लिए स्टेटस बार नीचे खींचकर 'बटन दिखाएँ' दबाएँ",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun showButton() {
        val tv = button ?: return
        val l = lp ?: return
        if (!attached) {
            try { wm.addView(tv, l); attached = true } catch (_: Exception) {}
        }
        hidden = false
        updateNotif()
    }

    private var shownHits = 0
    private var shownMisses = 0
    private var shownSmashes = 0

    private val tick = object : Runnable {
        override fun run() {
            if (destroyed) return
            refreshButton()
            val e = engine
            if (e != null && (e.hits != shownHits || e.misses != shownMisses || e.smashes != shownSmashes)) {
                shownHits = e.hits; shownMisses = e.misses; shownSmashes = e.smashes
                updateNotif()
            }
            main.postDelayed(this, 300)
        }
    }

    private fun refreshButton() {
        val tv = button ?: return
        val st = engine?.status ?: Engine.ST_MENU
        val (label, color) = when {
            !running -> "OFF" to Color.GRAY
            st == Engine.ST_TRACK -> "ON" to Color.rgb(46, 160, 67)
            st == Engine.ST_NOBALL -> "ON" to Color.rgb(30, 110, 200)
            else -> "WAIT" to Color.rgb(230, 140, 0)
        }
        tv.text = label
        (tv.background as? GradientDrawable)?.setColor(color)
    }

    override fun onDestroy() {
        destroyed = true
        alive = false
        running = false
        main.removeCallbacksAndMessages(null)
        BotAccessibilityService.instance?.end()
        try { if (attached) button?.let { wm.removeView(it) } } catch (_: Exception) {}
        attached = false
        button = null
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        thread?.quitSafely()
        super.onDestroy()
    }
}
